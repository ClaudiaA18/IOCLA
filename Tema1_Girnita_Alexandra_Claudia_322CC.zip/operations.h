#ifndef _OPERATIONS_H_
#define _OPERATIONS_H_

void get_operations(void **operations);

#endif // _OPERATIONS_H_